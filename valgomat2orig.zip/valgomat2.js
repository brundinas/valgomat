const questions = ['Jeg er enig i gratis SFO', 'Jeg er uenig i bybane over Bryggen']; // ... add more questions

const questionT = document.getElementById('question')
const btnNext = document.getElementById('btnNext')
const rbAnswer = document.getElementsByName('answer')

btnNext.addEventListener('click', nextQuestion)

let qidx = 0
questionT.innerHTML = questions[qidx]

function nextQuestion() {
    let radioChecked = document.querySelector('input[name="answer"]:checked');
    
    if (radioChecked) {
        qidx++
        if (qidx < questions.length) {
            questionT.innerHTML = questions[qidx]
        }
        else { 
            calculateResult()
        }
    }

}

function calculateResult() {

}